use strict;
use warnings;
use File::Slurp;
use YAML::XS;
use Moose;

package Bio::Test;

# ABSTRACT: Create a pan genome
# Another comment

1;
